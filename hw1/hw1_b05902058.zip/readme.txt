4. Babe crypto
* python3 code4.py
* 找到有意義的句子複製貼上(Caesar cipher)

5. OTP
* python3 code5_{1}{2}.py

6. MD5 Collision
* git clone https://github.com/thereal1024/python-md5-collision.git
* 把code6.py移到這個目錄理
* python3 code6.py

7.8.9. Flag Market
* python3 code7.py