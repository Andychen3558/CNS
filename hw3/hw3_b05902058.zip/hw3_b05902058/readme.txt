1. My First Project
* g++ firstProject_patch.cpp -o firstProject_patch
* ./firstProject_patch

2. Pokemon Master
* bash code2.sh

3. Fuzz it!
* python3 code3.py

5. BGP and Network Model
* python3 code5_3.py
* python3 code5_4.py