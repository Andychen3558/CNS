4. NS Protocol Revenge
* python3 code4.py

5. TLS
* python3 code5.py

6. Eve’s Revenge
* python2 code8.py